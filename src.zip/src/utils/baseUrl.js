// export const apiurl = "http://54.198.55.249:8159/api/v1/"
export const apiurl = "http://192.168.100.37:8159/api/v1/"
//export const apiurl = "http://localhost:8159/api/v1/"
