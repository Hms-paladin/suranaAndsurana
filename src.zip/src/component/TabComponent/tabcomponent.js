import React from 'react';
import './tabcompoent.scss';

export default function TabComponent(){
    return(
        <div>
            <p></p>
        </div>
    )
}
